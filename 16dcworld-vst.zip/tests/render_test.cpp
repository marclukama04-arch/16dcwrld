// Test du moteur seul : g++ -O2 -std=c++17 tests/render_test.cpp -o test && ./test
#include "../Source/Engine.h"
#include <cstdio>
int main()
{
    tsh::Engine e; e.prepare (44100); int fails = 0;
    for (int i = 0; i < 16; ++i)
    {
        const auto& p = tsh::kPresets[i];
        e.setPreset (i); e.setParams ({ p.cutoff, p.reso, p.glide, p.attack, p.release });
        const int note = p.cat == 2 ? 36 : 60; e.noteOn (note, 0.8f);
        double e0 = 0, e1 = 0, e2 = 0; float peak = 0; bool bad = false;
        for (int n = 0; n < 44100 * 4; ++n)
        {
            if (n == 44100 * 2) e.noteOff (note);
            const float s = e.tick(); if (! std::isfinite (s)) bad = true; peak = std::max (peak, std::fabs (s));
            if (n < 8820) e0 += s * s; else if (n >= 44100 && n < 44100 + 8820) e1 += s * s; else if (n >= 44100 * 3 && n < 44100 * 3 + 8820) e2 += s * s;
        }
        const bool ok = ! bad && peak > 0.05f && peak <= 1.0f && e0 > 0 && e2 < e0 * 0.05;
        std::printf ("%-14s peak %.2f  rms debut %.3f  rms 1s %.3f  rms apres relache %.4f  voix actives %d  %s\n",
                     p.name, peak, std::sqrt (e0 / 8820), std::sqrt (e1 / 8820), std::sqrt (e2 / 8820), e.activeVoices(), ok ? "OK" : "PROBLEME");
        if (! ok) ++fails;
    }
    // accord de 4 notes : pas de saturation excessive
    e.setPreset (0); e.setParams ({ 2200, .1f, 0, .002f, .6f }); for (int n : { 60, 64, 67, 72 }) e.noteOn (n, 1.0f);
    float pk = 0; for (int n = 0; n < 44100; ++n) pk = std::max (pk, std::fabs (e.tick()));
    std::printf ("Accord 4 notes vel max : peak %.2f\n", pk);
    std::printf (fails ? "%d preset(s) en probleme\n" : "Tous les presets sont OK\n", fails);
    return fails ? 1 : 0;
}
